# 📄 Research Reports

This directory contains formal progress reports and experimental summaries for the RLAE & SVAR research.

## Purpose

These reports synthesize raw logs from the `logs/` directory.

---
> [!NOTE]
> All PDF exports are generated from the canonical Markdown files to ensure data integrity across formats.
