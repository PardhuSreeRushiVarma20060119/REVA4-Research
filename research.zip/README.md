# 🛡️ RLAE & SVAR: Advanced Robustness Research Repository

> **Proving Intelligence through Bounded Invariance and Structural Perturbation.**

This repository is a technically rigorous research environment dedicated to the development and evaluation of **Runtime Low-Rank Adaptive Environments (RLAE)** and **Structural Variance Analysis for Robustness (SVAR)**. 

Our mission is to move AI alignment from "hidden weight mutation" to a **runtime-governed behavioral paradigm**, where intelligence is modular, reversible, and mathematically provable.

---

## 🔬 Theoretical Framework

### 1. RLAE (Runtime Low-Rank Adaptive Environments)
RLAE is a learning paradigm where reinforcement learning updates are applied **exclusively to LoRA parameters**. By keeping the base model permanently frozen, we externalize learning into "Adaptive Environments."
- **Frozen Core Invariance:** The foundation identity never changes.
- **Behavioral Externalization:** All skills exist as swappable LoRA artifacts.
- **Killability:** Any behavior can be destroyed instantly without model damage.

### 2. SVAR (Structural Variance Analysis for Robustness)
SVAR is our primary diagnostic framework. It assesses the stability of RLAE systems by applying controlled structural perturbations to the LoRA adapters.
- **Identity Leakage Score (ILS):** A fused metric tracking state drift.
- **Stability Envelopes:** Measuring behavior resilience under ε-bounded noise.
- **Non-Identity Persistence:** Ensuring a reset returns the system to a clean state.

---

## 🛠️ Technical Architecture

### **The "Frozen Core" Strategy**
We utilize **Qwen2.5-3B-Instruct** as our base model, loaded in 4-bit/16-bit quantization and strictly frozen. Intelligence is expanded through:
- **SFT Environment:** Supervised Fine-Tuning of behavioral instructions.
- **RL Alignment Environment:** DPO-based alignment towards specific preference distributions.

### **Advanced Robustness Hardening**
- **⚡ CUDA OOM Protection:** A stateful decorator (`@cuda_oom_protect`) that automatically detects VRAM exhaustion, clears GPU cache, and synchronizes the device for seamless experiment continuity.
- **🔍 ILS (Identity Leakage Score):** A multi-metric fusion (KL Divergence + Embedding Drift + Entropy Variance) that quantifies model integrity with 0.01 precision.
- **📐 Magnitude-Based Pruning:** Automatic structural thinning of adapters to identify the "behavioral core" of learned skills.

---

## 🚀 Cloud Execution Guide (Google Colab T4)

The repository is optimized for the **NVIDIA T4 GPU (16GB VRAM)**. Follow these phases for a canonical research run:

### **Phase 1: Environment Setup**
```bash
# Upload research.zip and extract
!unzip research.zip
%cd experiments
!pip install -q -r requirements.txt
```

### **Phase 2: Establish Invariance Lifecycle**
Execute these scripts sequentially to build and verify the environment:
1.  **Baseline Run:** `!python src/exp1_reset/1_baseline.py` (Established Original Identity)
2.  **SFT Training:** `!python src/exp1_reset/2_train_sft.py` (Mounting Behavior)
3.  **RL Alignment:** `!python src/exp1_reset/3_train_rl.py` (Fine-tuning preference)
4.  **Reset Verification:** `!python src/exp1_reset/4_verify_reset.py` (**CRITICAL:** Proves ILS < 0.05)

### **Phase 3: Robustness Diagnostics**
1.  **Behavioral Elimination:** `!python src/exp2_rlae/elimination_test.py`
2.  **SVAR Perturbation:** `!python src/exp3_svar/perturbation.py`
3.  **Unified Report:** `!python src/verification/robustness_suite.py`

---

## 📊 Governance & Monitoring

### **Runtime Governance Surface**
Launch the interactive dashboard to monitor the experimental lifecycle in real-time:
```bash
!python src/utils/browser_app.py
```
Provides:
- Real-time VRAM telemetry.
- Dynamic LoRA loading/unloading.
- **Emergency Kill Path:** Immediate state destruction.

### **Identity Leakage Analysis**
| Metric | Threshold | Meaning |
| :--- | :--- | :--- |
| **ILS < 0.05** | ✅ HEALTHY | Core invariance preserved. |
| **ILS 0.05 - 0.10** | ⚠️ DRIFT | Minor hardware non-determinism. |
| **ILS > 0.10** | ❌ LEAKAGE | Core identity corruption detected. |

---

## 📂 Repository Structure

```text
├── data/               # Training instructions & preference sets
├── logs/               # Telemetry, memory, and ILS logs
├── models/             # Persisted LoRA behavioral artifacts
├── project-scope/      # Canonical documentation (RLAE/SVAR)
├── src/                # Core implementation
│   ├── analysis/       # Post-experiment drift analysis
│   ├── exp1_reset/     # Baseline and Reset Invariance tests
│   ├── exp2_rlae/      # Magnitude-based thinning/elimination
│   ├── exp3_svar/      # Structural perturbation suite
│   ├── utils/          # Model loaders, OOM protect, Metrics
│   └── verification/   # Unified Robustness Suite
└── WALKTHROUGH.md      # Detailed phase-by-phase guide
```

---

> [!NOTE]
> This repository is designed for **deterministic research**. All experiments are logged with timestamps and hardware telemetry to ensure reproducibility across different CUDA environments.

**Status:** `READY` | **Hardened:** `YES` | **Robustness Profile:** `ADVANCED`
